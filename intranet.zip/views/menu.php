<ul class="sidebar-menu" data-widget="tree">
    <li class="header">NAVEGACIÓN</li>
    <!-- Optionally, you can add icons to the links -->
    <li><a href="grupo"><i class="fa fa-link"></i> <span>Grupos</span></a></li>
    <li><a href="horario"><i class="fa fa-link"></i> <span>Horarios</span></a></li>
    <li><a href="alumno"><i class="fa fa-link"></i> <span>Alumnos</span></a></li>
    <li><a href="docente"><i class="fa fa-link"></i> <span>Docentes</span></a></li>
    <li class="treeview" >
        <a href="#">
        <i class="fa fa-table"></i> <span>Participantes</span>
        <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
        </span>
        </a>
        <ul class="treeview-menu">
        <li class="active"><a href="participante"> Reporte de Audiciones 2019</a></li>
        <li><a href="descarga.php"><i class="fa fa-circle-o"></i> Descarga de Correos</a></li>
        <li><a href="evaluacion.php"><i class="fa fa-circle-o"></i> Evaluación de Audiciones 2019</a></li>
        </ul>
    </li>
</ul>