<?php
class Apoderado
{
    public $idapoderado;
    public $nombres;
    public $apellidos;
    public $correo;
    public $celular;
    public $estado;
}
?>