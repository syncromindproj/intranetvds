<?php

class Alumno
{
    public $idparticipante;
    public $nombres;
    public $apellidos;
    public $correo_postulante;
    public $celular_postulante;
    public $fecha_nacimiento;
    public $edad;
    public $distrito;
    public $centro_estudios;
    public $anio_estudios;
    public $nombre_apoderado;
    public $celular_apoderado;
    public $correo_apoderado;
    public $aprobado;
    public $estado;
    
    public $idparticipante_detalle;
    public $dni;
    public $direccion;
    public $estudia_canto;
    public $donde_estudia;
    public $seguro_salud;
    public $alergias;
    public $dolor_cabeza;
    public $fiebre;
    public $dolor_estomago;
    public $toma_medicamento_diario;
    public $medicamento_diario;
}

?>