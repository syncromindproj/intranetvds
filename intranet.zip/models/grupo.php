<?PHP

class Grupo{
    public $idgrupo;
    public $descripcion;
    public $estado;
}

?>