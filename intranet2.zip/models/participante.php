<?PHP

class Participante{
    public $idparticipante;
    public $nombres;
    public $apellidos;
    public $correo_postulante;
    public $celular_postulante;
    public $fecha_nacimiento;
    public $edad;
    public $distrito;
    public $centro_estudios;
    public $anio_estudios;
    public $nombre_apoderado;
    public $celular_apoderado;
    public $correo_apoderado;
    public $aprobado;
    public $estado;
}

?>