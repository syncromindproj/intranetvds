<?php
class Apoderado
{
    public $idapoderado;
    public $nombres;
    public $apellidos;
    public $correo;
    public $celular;
    public $estado;
    public $dni;
    public $direccion;
    public $telefono_fijo;
    public $encargado_pagos;
}
?>