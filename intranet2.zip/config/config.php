<?PHP
define('URL', 'http://localhost:8080/intranet/');

define('HOST', 'localhost');
define('DB', 'voces');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');
define('TITLE', 'Voces del Sol');
?>